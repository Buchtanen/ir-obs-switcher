# PITWALL LIGHT - implementation asset package

Produkční sada světlého minimalistického theme pro Buchtanen iRacer OBS Browser Source. SVG jsou master vrstvy; PNG a lossless WebP jsou transparentní odvozené exporty v 1x a 2x. Živý text, jména, pozice, gapy, časy, BPM a systémové hodnoty nejsou zapečené do grafiky.

## Neměnný kontrakt

- transient widgety: `420 x 140 px` ve všech lifecycle stavech;
- expanded BLE/HR: `420 x 140 px`;
- compact BLE/HR: `180 x 72 px`, určený do SYSINFO;
- permanentní SYSINFO: `1920 x 72 px` na spodním okraji canvasu `1920 x 1080`;
- `COMPACT` mění informační hustotu, nikoli rozměr karty;
- střed obrazu zůstává volný.

## Obsah

- `assets/vector/` - master SVG, masky, ikony a oddělené animační vrstvy;
- `assets/raster/png/{1x,2x}` - transparentní RGBA PNG;
- `assets/raster/webp/{1x,2x}` - transparentní lossless WebP;
- `tokens/` - design tokeny a mapování eventů;
- `manifests/` - rozměry, anchory, safe areas, z-index, role, stavové barvy, SHA-256;
- `examples/` - HTML/CSS skládání a souborové kompozice;
- `docs/` - implementační, motion a OBS guide.

Začněte v `docs/IMPLEMENTATION.md` a `examples/html/widget-composition.html`.
