# Theme 4 - Pitwall / Race Control

Produkční asset package pro Buchtanen iRacer OBS Browser Source. Sada je tvořena samostatnými transparentními vrstvami; neobsahuje kontaktní sheet ani zapečená živá data.

## Neměnný kontrakt

- každý transientní widget: přesně `420 x 140 px` ve stavech ENTER, ACTIVE, COMPACT, SUSPENDED i EXIT;
- SYSINFO: přesně `1920 x 72 px`;
- canvas: `1920 x 1080`, transparentní;
- střed obrazu zůstává volný;
- `COMPACT` nikdy nemění vnější rozměr;
- text, jména, pozice, gapy, časy, teploty, výkon, BPM a ostatní data renderuje HTML.

## Formáty

- `assets/vector/`: master SVG, vhodné pro inline SVG, `<img>`, masky a CSS animaci;
- `assets/raster/png/{1x,2x}`: transparentní RGBA PNG;
- `assets/raster/webp/{1x,2x}`: lossless transparentní WebP;
- `tokens/`: design a event tokeny;
- `examples/`: referenční HTML/CSS skládání;
- `manifests/`: strojově čitelný index, rozměry, SHA-256 a velikosti.

## Vrstvení transientu

1. `01-plate-base`
2. `02-data-surface`
3. `06-technical-grid`
4. `05-timing-ticks`
5. event-specific divider / trace
6. `03-border`
7. `04-status-rail-*`
8. ikona
9. corner/accent/motion fragment
10. dynamický HTML obsah

Podrobnosti jsou v `docs/IMPLEMENTATION.md`, `docs/LAYERING_AND_ANCHORS.md`, `docs/MOTION.md` a `docs/OBS_BROWSER_SOURCE.md`.
